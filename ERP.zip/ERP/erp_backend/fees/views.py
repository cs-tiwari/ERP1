from django.shortcuts import render, redirect, get_object_or_404
from .models import Fee
from .forms import FeeForm

def fee_list(request):
    fees = Fee.objects.select_related('student').all()
    return render(request, 'fees/fee_list.html', {'fees': fees})

def fee_create(request):
    form = FeeForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('fees:fee_list')
    return render(request, 'fees/fee_form.html', {'form': form})

def fee_update(request, pk):
    fee = get_object_or_404(Fee, pk=pk)
    form = FeeForm(request.POST or None, instance=fee)
    if form.is_valid():
        form.save()
        return redirect('fees:fee_list')
    return render(request, 'fees/fee_form.html', {'form': form})

def fee_delete(request, pk):
    fee = get_object_or_404(Fee, pk=pk)
    if request.method == 'POST':
        fee.delete()
        return redirect('fees:fee_list')
    return render(request, 'fees/fee_confirm_delete.html', {'fee': fee})
