from django import forms
from .models import Fee

class FeeForm(forms.ModelForm):
    class Meta:
        model = Fee
        fields = ['student', 'amount', 'due_date', 'is_paid', 'paid_on', 'remarks']
        widgets = {
            'due_date': forms.DateInput(attrs={'type': 'date'}),
            'paid_on': forms.DateInput(attrs={'type': 'date'}),
        }
