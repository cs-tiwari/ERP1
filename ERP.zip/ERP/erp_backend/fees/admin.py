from django.contrib import admin
from .models import Fee

@admin.register(Fee)
class FeeAdmin(admin.ModelAdmin):
    list_display = ('student', 'amount', 'due_date', 'paid', 'payment_date')
    list_filter = ('paid',)
    search_fields = ('student__first_name', 'student__last_name')
