from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from students.models import Student
from admissions.models import Admission
from exams.models import Exam
from fees.models import Fee
from inventory.models import Product, Category

@login_required
def dashboard(request):
    context = {
        'total_students': Student.objects.count(),
        'total_admissions': Admission.objects.count(),
        'total_exams': Exam.objects.count(),
        'total_fees': Fee.objects.count(),
        'total_products': Product.objects.count(),
        'total_categories': Category.objects.count(),
    }
    return render(request, 'dashboard.html', context)
