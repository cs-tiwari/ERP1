from django.contrib import admin
from django.urls import path, include
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from django.shortcuts import redirect  # 👈 Needed for root redirect
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('admin/', admin.site.urls),

    # App routes
    path('students/', include('students.urls')),

    path('notifications/', include('notifications.urls')),
    path('accounts/', include('accounts.urls', namespace='accounts')),
    path('dashboard/', include('dashboard.urls', namespace='dashboard')),
   
    # Add to erp_backend/urls.py if missing
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('admissions/', include('admissions.urls', namespace='admissions')),
    path('exams/', include('exams.urls', namespace='exams')),
    path('fees/', include('fees.urls', namespace='fees')),
    path('inventory/', include('inventory.urls', namespace='inventory')),






    # JWT endpoints
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    # Redirect root URL to ERP dashboard
    path('', lambda request: redirect('dashboard:dashboard')),
    

]
