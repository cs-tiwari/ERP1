from django.urls import path
from .views import NotificationListCreateAPIView, NotificationRetrieveUpdateDestroyAPIView

urlpatterns = [
    path('', NotificationListCreateAPIView.as_view(), name='notification-list-create'),
    path('<int:pk>/', NotificationRetrieveUpdateDestroyAPIView.as_view(), name='notification-detail'),
]
