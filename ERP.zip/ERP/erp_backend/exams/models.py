# exams/models.py

from django.db import models

class Exam(models.Model):
    name = models.CharField(max_length=100)
    exam_date = models.DateField()
    total_marks = models.PositiveIntegerField()
    passing_marks = models.PositiveIntegerField()

    def __str__(self):
        return self.name
