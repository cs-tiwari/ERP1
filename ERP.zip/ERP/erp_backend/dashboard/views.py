from django.contrib.auth.decorators import login_required
from django.shortcuts import render

def get_summary_counts():
    from students.models import Student
    from admissions.models import Admission
    from exams.models import Exam
    from fees.models import Fee
    from inventory.models import Product, Category

    return {
        'total_students': Student.objects.count(),
        'total_admissions': Admission.objects.count(),
        'total_exams': Exam.objects.count(),
        'total_fees': Fee.objects.count(),
        'total_products': Product.objects.count(),
        'total_categories': Category.objects.count(),
    }

@login_required
def dashboard(request):
    context = get_summary_counts()
    return render(request, 'dashboard/dashboard.html', context)  # ✅ Updated template path
