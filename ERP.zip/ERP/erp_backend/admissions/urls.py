from django.urls import path
from . import views

app_name = 'admissions'

urlpatterns = [
    path('', views.admission_list, name='admission_list'),
    path('create/', views.admission_create, name='admission_create'),
    path('<int:pk>/update/', views.admission_update, name='admission_update'),
    path('<int:pk>/delete/', views.admission_delete, name='admission_delete'),
]
