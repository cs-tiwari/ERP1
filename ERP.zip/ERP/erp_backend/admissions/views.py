from django.shortcuts import render, redirect, get_object_or_404
from .models import Admission
from .forms import AdmissionForm

def admission_list(request):
    admissions = Admission.objects.select_related('student')
    return render(request, 'admissions/admission_list.html', {'admissions': admissions})

def admission_create(request):
    if request.method == 'POST':
        form = AdmissionForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('admissions:admission_list')
    else:
        form = AdmissionForm()
    return render(request, 'admissions/admission_form.html', {'form': form})

def admission_update(request, pk):
    admission = get_object_or_404(Admission, pk=pk)
    if request.method == 'POST':
        form = AdmissionForm(request.POST, instance=admission)
        if form.is_valid():
            form.save()
            return redirect('admissions:admission_list')
    else:
        form = AdmissionForm(instance=admission)
    return render(request, 'admissions/admission_form.html', {'form': form})

def admission_delete(request, pk):
    admission = get_object_or_404(Admission, pk=pk)
    if request.method == 'POST':
        admission.delete()
        return redirect('admissions:admission_list')
    return render(request, 'admissions/admission_confirm_delete.html', {'admission': admission})
