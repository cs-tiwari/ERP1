from django.contrib import admin
from .models import Admission

@admin.register(Admission)
class AdmissionAdmin(admin.ModelAdmin):
    list_display = ('admission_number', 'student', 'admission_date', 'course', 'status')
    list_filter = ('status', 'course')
    search_fields = ('admission_number', 'student__first_name', 'student__last_name')
