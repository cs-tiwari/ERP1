from django.db import models
from students.models import Student

class Admission(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    admission_date = models.DateField()
    course = models.CharField(max_length=100)
    status = models.CharField(max_length=50, choices=[
        ('confirmed', 'Confirmed'),
        ('pending', 'Pending'),
        ('cancelled', 'Cancelled')
    ])

    def __str__(self):
        return f"{self.student} - {self.course}"
