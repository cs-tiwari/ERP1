// inventory/static/js/scripts.js
document.addEventListener("DOMContentLoaded", function () {
  console.log("ERP Dashboard Ready 🚀");
});
